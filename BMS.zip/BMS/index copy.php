<?php
	include("includes/header.php");
?>

<div id="content">
	<div class="post">
		<h2 class="title"><a href="#">Welcome to Bookstore Management System</a></h2>
			<p class="meta"></p>
			<div class="entry">
				Your Design
			</div>
	</div>
</div><!-- end #content -->

<?php
	include("includes/footer.php");
?>